local direct_control = {
    type = "custom-input",
    name = "spidertron-enhancements-enter-vehicles",
    key_sequence = "U",
  }

data:extend{direct_control}