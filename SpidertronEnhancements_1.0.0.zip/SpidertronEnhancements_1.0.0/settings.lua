data:extend({
    {
        type = "bool-setting",
        name = "spidertron-enhancements-enter-entity-base-game",
        setting_type = "runtime-global",
        default_value = true
    },
    {
        type = "bool-setting",
        name = "spidertron-enhancements-enter-entity-custom",
        setting_type = "runtime-global",
        default_value = true
    },
    {
        type = "bool-setting",
        name = "spidertron-enhancements-enter-player",
        setting_type = "runtime-global",
        default_value = true
    },
    {
        type = "bool-setting",
        name = "spidertron-enhancements-spill-on-death",
        setting_type = "runtime-global",
        default_value = true
    },
})